# Pokémon Battle Arena — Board.fun Unity Port

## Quick Setup

1. **Create a new Unity 2D project** (Unity 2021.3+ recommended)
2. **Import the Board SDK** into your project
3. **Copy** all `.cs` files from this folder into `Assets/Scripts/`
4. **Create a scene** called `MainScene`:
   - Add an empty GameObject named `GameManager` → attach `GameManager.cs`
   - Add an empty GameObject named `InputManager` → attach `TouchInputManager.cs`
   - Add an empty GameObject named `UIManager` → attach `UIManager.cs`
   - Add a Camera (Orthographic, size ~6)
   - Set canvas resolution to 1920×1080 (Board's native)
5. **Sprites**: The game downloads Pokémon sprites from PokeAPI at runtime.
   No manual sprite assets needed.

## Project Structure

```
Assets/Scripts/
├── Core/
│   ├── GameManager.cs       — Game state machine + arena
│   ├── Fighter.cs           — Player/enemy entity
│   ├── Projectile.cs        — Projectile behavior
│   └── CombatSystem.cs      — Damage calculation + type chart
├── Data/
│   └── PokemonDatabase.cs   — All Pokémon stats + attacks
├── AI/
│   └── AIController.cs      — Enemy AI (chase, attack, flee)
├── Input/
│   └── TouchInputManager.cs — Virtual joystick + attack buttons
└── UI/
    └── UIManager.cs          — Menu, HUD, game over screens
```

## Board.fun Integration Notes

- **Input**: Uses `UnityEngine.Input.touches` which maps directly to Board's touchscreen
- **No physical pieces required**: Plays as a pure touchscreen game
- **Orientation**: Designed for landscape/tabletop (horizontal) play
- **Multiplayer**: Two players can sit on opposite sides of the Board
  - P1 joystick+buttons on the left/bottom
  - P2 joystick+buttons on the right/top

## Board SDK Hooks (Optional)

The `GameManager.cs` has placeholder hooks for:
- `BoardSDK.OnPiecePlace` — could be used to select Pokémon by placing a physical piece
- `BoardSDK.OnSessionStart/End` — for Board session lifecycle
- `BoardSDK.SaveGame/LoadGame` — for save state

These are commented out and can be enabled once the Board SDK is imported.
