# Pokémon Battle Arena — Unity Setup Guide (Step by Step)

## Prerequisites

- **Unity Hub** installed → [Download here](https://unity.com/download)
- **Unity Editor 2021.3 LTS** or newer (2022.3 LTS recommended)
- **Board SDK** (from the Board.fun developer program)

---

## Step 1: Create a New Unity Project

1. Open **Unity Hub**
2. Click **"New Project"** (top right)
3. Select template: **"2D (Built-in Render Pipeline)"**
   - ⚠️ Do NOT pick "2D URP" — the scripts use `Sprites/Default` shader which is built-in only
4. Name it: `PokemonBattleArena`
5. Choose a save location
6. Click **"Create project"**
7. Wait for Unity to open (first load takes a few minutes)

---

## Step 2: Copy the Script Files

1. In your file browser, navigate to where the scripts are:
   ```
   /usr/local/google/home/freitag/.gemini/jetski/brain/ae199744-befc-4bce-9b99-6514330dfd58/artifacts/board_unity_project/Scripts/
   ```

2. Copy the **entire `Scripts` folder** into your Unity project's `Assets` folder:
   ```
   PokemonBattleArena/
   └── Assets/
       └── Scripts/          ← paste here
           ├── AI/
           │   └── AIController.cs
           ├── Core/
           │   ├── Fighter.cs
           │   ├── GameManager.cs
           │   └── Projectile.cs
           ├── Data/
           │   └── PokemonDatabase.cs
           ├── Input/
           │   └── TouchInputManager.cs
           └── UI/
               └── UIManager.cs
   ```

3. Switch back to Unity — it will **auto-detect** the new scripts and compile them
4. Wait for the progress bar at the bottom to finish ("Compiling scripts...")
5. If you see errors in the Console (bottom panel), check the [Troubleshooting](#troubleshooting) section below

---

## Step 3: Set Up the Scene

Unity opens with a default scene called `SampleScene`. We'll use it.

### 3a. Create the GameManager

1. In the **Hierarchy** panel (left side), right-click → **Create Empty**
2. Name it `GameManager` (click on the new object, then type the name in the Inspector on the right)
3. In the **Inspector** panel (right side), click **"Add Component"**
4. Type `GameManager` in the search box → click it to attach
5. Make sure its Transform position is `(0, 0, 0)`

### 3b. Create the InputManager

1. Right-click in Hierarchy → **Create Empty**
2. Name it `InputManager`
3. Click **"Add Component"** → search and attach `TouchInputManager`
4. Position: `(0, 0, 0)`

### 3c. Create the UIManager

1. Right-click in Hierarchy → **Create Empty**
2. Name it `UIManager`
3. Click **"Add Component"** → search and attach `UIManager`
4. Position: `(0, 0, 0)`

### Your Hierarchy should now look like this:
```
📁 SampleScene
   📷 Main Camera
   🎮 GameManager       [GameManager.cs]
   🕹️ InputManager      [TouchInputManager.cs]
   🖥️ UIManager         [UIManager.cs]
```

---

## Step 4: Configure the Camera

1. Click on **"Main Camera"** in the Hierarchy
2. In the Inspector, set these values:
   - **Projection**: `Orthographic` (should already be set for 2D)
   - **Size**: `5.5`
   - **Position**: `(0, 0, -10)`
   - **Background Color**: Click the color swatch → set to dark blue `#0A0A24` (R:10 G:10 B:36)
3. The GameManager script will also adjust the camera at runtime, but this gives a good starting view

---

## Step 5: Save the Scene

1. Press **Ctrl+S** (or Cmd+S on Mac)
2. If prompted, save as `MainScene` in the `Assets/Scenes/` folder

---

## Step 6: Hit Play! ▶️

1. Click the **▶️ Play** button at the top center of Unity
2. You should see:
   - A dark background with a red arena border
   - The menu with mode buttons (1 Player, 2P PvP, Co-op, Training)
   - Pokémon selection buttons
   - Difficulty selection
   - A "START BATTLE" button

### Controls (in Play mode):
| Action | Key |
|--------|-----|
| Move | WASD or Arrow Keys |
| Quick Attack | J |
| Special Attack | K |
| Ultimate Attack | L |
| Ultra Attack | U |
| Dodge | Space |

---

## Step 7: Import the Board SDK (Optional)

> Only needed if you want to run on actual Board hardware

1. Get the Board SDK `.unitypackage` file from the developer program
2. In Unity: **Assets** → **Import Package** → **Custom Package...**
3. Select the Board SDK `.unitypackage`
4. Click **Import All**
5. Open `GameManager.cs` and **uncomment** the Board SDK hooks (lines marked with `// ---Board SDK hooks ---`):

```csharp
// Uncomment these lines:
void OnEnable() {
    BoardSDK.OnPiecePlace += HandlePiecePlace;
    BoardSDK.OnSessionStart += HandleSessionStart;
}
void OnDisable() {
    BoardSDK.OnPiecePlace -= HandlePiecePlace;
    BoardSDK.OnSessionStart -= HandleSessionStart;
}
void HandlePiecePlace(BoardPiece piece) {
    Debug.Log($"Piece placed: {piece.Id}");
}
```

6. Build for **Android** (Board runs Android):
   - **File** → **Build Settings**
   - Switch platform to **Android**
   - Set resolution to **1920×1080** (Board's native resolution)
   - Build and sideload onto Board

---

## Step 8: Build Settings (for Board)

1. **File** → **Build Settings**
2. Click **Android** → **Switch Platform**
3. Click **Player Settings** (bottom left)
4. Set:
   - **Company Name**: your name
   - **Product Name**: `Pokemon Battle Arena`
   - **Default Orientation**: `Landscape Left`
   - **Resolution**: 1920 × 1080
   - **Minimum API Level**: Android 8.0 (API 26) or higher
5. Click **Build** → save the `.apk` file
6. Sideload onto Board via USB or the Board developer tools

---

## Troubleshooting

### "Type or namespace 'UnityEngine.UI' could not be found"
The scripts use Unity's UI system. Fix:
1. In the Project panel, right-click → **Create** → **Assembly Definition**
2. Or simply ensure the project has the **Unity UI** package:
   - **Window** → **Package Manager** → search for "Unity UI" → Install

### "LegacyRuntime.ttf not found"
The UI uses Unity's built-in font. If this fails:
1. Open `UIManager.cs` and `TouchInputManager.cs`
2. Replace `Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf")` with `Resources.GetBuiltinResource<Font>("Arial.ttf")`

### Sprites not loading (blank white circles)
The game downloads sprites from PokeAPI at runtime. Ensure:
- Your computer has internet access
- Unity's **Project Settings** → **Player** → **Allow downloads over HTTP** is enabled (or the URLs use HTTPS, which they do)

### Objects too big/small
- Adjust the Camera's **Orthographic Size** (try values between 4 and 8)
- The arena is 16×9 world units, centered at origin

### Touch controls don't appear on PC
- That's expected! Touch controls auto-hide on non-touch devices
- Use keyboard (WASD + JKL + U + Space) for PC testing
- To test touch UI on PC: change `isTouch` to `true` in `TouchInputManager.cs`

---

## Project File Summary

| File | What it does |
|------|-------------|
| `PokemonDatabase.cs` | All 7 Pokémon: stats, attacks, type chart, sprite URLs |
| `Fighter.cs` | Player/enemy entity: HP, movement, dodge, damage, sprite loading |
| `Projectile.cs` | Projectile physics: collision, piercing, AOE, homing |
| `GameManager.cs` | Game state machine, spawn fighters, all 7 ultra attacks, Board SDK hooks |
| `AIController.cs` | Enemy AI: chase/attack/flee, wall avoidance, difficulty scaling |
| `TouchInputManager.cs` | Virtual joystick + attack buttons + keyboard fallback |
| `UIManager.cs` | Menu, HUD, game over — all created programmatically (no prefabs needed) |
