using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Projectile behavior — moves in a direction, checks collision with fighters.
/// </summary>
public class Projectile : MonoBehaviour
{
    public Fighter owner;
    public PokemonDatabase.PokemonType ownerType;
    public float damage;
    public float speed;
    public float size;
    public float lifetime;
    public bool piercing;
    public float aoe;
    public Vector2 direction;
    public string attackType;

    // Homing
    public Fighter homingTarget;
    public float homingStrength = 0.15f;

    private HashSet<Fighter> hitFighters = new HashSet<Fighter>();
    private SpriteRenderer sr;
    private TrailRenderer trail;

    public void Init(Fighter owner, Vector2 dir, PokemonDatabase.AttackData attack, string type)
    {
        this.owner = owner;
        this.ownerType = owner.data.type;
        this.direction = dir.normalized;
        this.damage = attack.damage;
        this.speed = attack.speed;
        this.size = attack.size;
        this.lifetime = attack.lifetime;
        this.piercing = attack.piercing;
        this.aoe = attack.aoe;
        this.attackType = type;

        transform.position = (Vector2)owner.transform.position + dir.normalized * (owner.radius + 0.2f);
        transform.localScale = Vector3.one * size;

        // Visual
        sr = GetComponent<SpriteRenderer>();
        if (sr == null) sr = gameObject.AddComponent<SpriteRenderer>();
        sr.color = attack.color;
        sr.sortingOrder = 5;

        // Make a circle sprite
        sr.sprite = CreateCircleSprite();

        // Trail
        trail = gameObject.AddComponent<TrailRenderer>();
        trail.time = 0.15f;
        trail.startWidth = size * 0.8f;
        trail.endWidth = 0;
        trail.material = new Material(Shader.Find("Sprites/Default"));
        trail.startColor = attack.color;
        trail.endColor = new Color(attack.color.r, attack.color.g, attack.color.b, 0);
        trail.sortingOrder = 4;
    }

    void Update()
    {
        lifetime -= Time.deltaTime;
        if (lifetime <= 0)
        {
            Destroy(gameObject);
            return;
        }

        // Homing
        if (homingTarget != null && homingTarget.alive)
        {
            Vector2 toTarget = (Vector2)homingTarget.transform.position - (Vector2)transform.position;
            float dist = toTarget.magnitude;
            if (dist > 0.1f)
            {
                Vector2 desired = toTarget.normalized * speed;
                direction = Vector2.Lerp(direction, desired.normalized, homingStrength).normalized;
            }
        }

        // Move
        transform.position += (Vector3)(direction * speed * Time.deltaTime * 60f * 0.05f);

        // Off-screen check
        Vector2 pos = transform.position;
        float arenaW = GameManager.ArenaWidth / 2f + 2f;
        float arenaH = GameManager.ArenaHeight / 2f + 2f;
        if (Mathf.Abs(pos.x) > arenaW || Mathf.Abs(pos.y) > arenaH)
        {
            Destroy(gameObject);
            return;
        }

        // Collision with fighters
        CheckCollisions();
    }

    void CheckCollisions()
    {
        foreach (Fighter f in GameManager.Instance.GetAllFighters())
        {
            if (f == owner || !f.alive || hitFighters.Contains(f)) continue;

            // Friendly fire check
            if (!owner.isPlayer && !f.isPlayer) continue; // enemy can't hit enemy
            if (owner.isPlayer && f.isPlayer && owner != f) continue; // player can't hit player (co-op)

            float dist = Vector2.Distance(transform.position, f.transform.position);
            if (dist < f.radius + size * 0.5f)
            {
                hitFighters.Add(f);

                // Apply damage
                float mult = PokemonDatabase.GetTypeMultiplier(ownerType, f.data.type);
                float dmg = damage * mult;
                f.hp -= dmg;
                f.flashTimer = 0.13f;
                f.stunTimer = Mathf.Max(f.stunTimer, 0.08f);

                GameManager.Instance.SpawnDamageNumber(f.transform.position, dmg, mult > 1f);

                // AOE explosion
                if (aoe > 0)
                {
                    foreach (Fighter target in GameManager.Instance.GetAllFighters())
                    {
                        if (target == owner || !target.alive || hitFighters.Contains(target)) continue;
                        if (!owner.isPlayer && !target.isPlayer) continue;
                        if (owner.isPlayer && target.isPlayer) continue;

                        float aoeD = Vector2.Distance(transform.position, target.transform.position);
                        if (aoeD < aoe)
                        {
                            hitFighters.Add(target);
                            float aoeMult = PokemonDatabase.GetTypeMultiplier(ownerType, target.data.type);
                            float aoeDmg = damage * 0.6f * aoeMult;
                            target.hp -= aoeDmg;
                            target.flashTimer = 0.13f;
                            GameManager.Instance.SpawnDamageNumber(target.transform.position, aoeDmg, aoeMult > 1f);
                        }
                    }
                }

                if (!piercing)
                {
                    Destroy(gameObject);
                    return;
                }
            }
        }
    }

    static Sprite circleSprite;
    static Sprite CreateCircleSprite()
    {
        if (circleSprite != null) return circleSprite;
        int res = 32;
        Texture2D tex = new Texture2D(res, res);
        float center = res / 2f;
        float radius = res / 2f - 1;
        for (int x = 0; x < res; x++)
            for (int y = 0; y < res; y++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(center, center));
                tex.SetPixel(x, y, d <= radius ? Color.white : Color.clear);
            }
        tex.Apply();
        circleSprite = Sprite.Create(tex, new Rect(0, 0, res, res), new Vector2(0.5f, 0.5f), res);
        return circleSprite;
    }
}
