using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Main game state machine. Manages arena, fighters, combat, and game flow.
/// 
/// BOARD SDK INTEGRATION:
/// Uncomment the BoardSDK lines below when the Board SDK is imported.
/// The game works as a pure touchscreen game without physical pieces.
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    // Arena dimensions (in world units, centered at origin)
    public static float ArenaWidth = 16f;
    public static float ArenaHeight = 9f;

    public enum GameState { Menu, Playing, GameOver }
    public GameState state = GameState.Menu;

    [Header("Current Game")]
    public Fighter player;
    public Fighter player2;
    public List<Fighter> enemies = new List<Fighter>();
    public string currentDifficulty = "medium";
    public string selectedMode = "1p";
    public string selectedPokemon;
    public string selectedPokemonP2;
    public int selectedOpponents = 2;

    [Header("Prefabs")]
    public GameObject fighterPrefab;
    public GameObject projectilePrefab;

    // --- Board SDK hooks (uncomment when SDK is imported) ---
    // void OnEnable() {
    //     BoardSDK.OnPiecePlace += HandlePiecePlace;
    //     BoardSDK.OnSessionStart += HandleSessionStart;
    // }
    // void OnDisable() {
    //     BoardSDK.OnPiecePlace -= HandlePiecePlace;
    //     BoardSDK.OnSessionStart -= HandleSessionStart;
    // }
    // void HandlePiecePlace(BoardPiece piece) {
    //     // Could map physical pieces to Pokémon selection
    //     Debug.Log($"Piece placed: {piece.Id}");
    // }

    void Awake()
    {
        Instance = this;
        CreatePrefabs();
    }

    void CreatePrefabs()
    {
        // Fighter prefab
        fighterPrefab = new GameObject("FighterPrefab");
        fighterPrefab.AddComponent<SpriteRenderer>();
        fighterPrefab.AddComponent<Fighter>();
        fighterPrefab.SetActive(false);

        // Projectile prefab
        projectilePrefab = new GameObject("ProjectilePrefab");
        projectilePrefab.AddComponent<SpriteRenderer>();
        projectilePrefab.AddComponent<Projectile>();
        projectilePrefab.SetActive(false);

        // Draw arena border
        DrawArenaBorder();
    }

    void DrawArenaBorder()
    {
        var border = new GameObject("ArenaBorder");
        var lr = border.AddComponent<LineRenderer>();
        lr.positionCount = 5;
        lr.startWidth = 0.08f;
        lr.endWidth = 0.08f;
        lr.material = new Material(Shader.Find("Sprites/Default"));
        lr.startColor = new Color(0.91f, 0.27f, 0.38f);
        lr.endColor = new Color(0.91f, 0.27f, 0.38f);
        lr.loop = true;
        float w = ArenaWidth / 2f;
        float h = ArenaHeight / 2f;
        lr.SetPositions(new Vector3[] {
            new(-w, -h, 0), new(w, -h, 0), new(w, h, 0), new(-w, h, 0), new(-w, -h, 0)
        });

        // Dark background
        Camera.main.backgroundColor = new Color(0.04f, 0.04f, 0.14f);
        Camera.main.orthographic = true;
        Camera.main.orthographicSize = ArenaHeight / 2f + 0.5f;
    }

    void Start()
    {
        // Show menu (handled by UIManager)
        state = GameState.Menu;
    }

    // ============================================================
    // GAME START
    // ============================================================

    public void StartGame()
    {
        state = GameState.Playing;

        // Clean up old fighters
        foreach (var f in FindObjectsOfType<Fighter>())
            if (f.gameObject != fighterPrefab) Destroy(f.gameObject);
        foreach (var p in FindObjectsOfType<Projectile>())
            if (p.gameObject != projectilePrefab) Destroy(p.gameObject);

        enemies.Clear();
        player = null;
        player2 = null;

        if (selectedMode == "1p" || selectedMode == "training")
        {
            player = SpawnFighter(selectedPokemon, new Vector2(0, -ArenaHeight / 2f + 2f), true);

            if (selectedMode == "training")
            {
                // Training dummy
                var dummyIds = PokemonDatabase.All.Keys.Where(id => id != selectedPokemon).ToList();
                var dummyId = dummyIds[Random.Range(0, dummyIds.Count)];
                var dummy = SpawnFighter(dummyId, new Vector2(0, ArenaHeight / 2f - 3f), false);
                dummy.hp = 99999;
                dummy.maxHp = 99999;
                dummy.isTrainingDummy = true;
                dummy.radius = 1.4f;
                dummy.transform.localScale = Vector3.one * 2.8f;
                enemies.Add(dummy);
            }
            else
            {
                // Spawn AI enemies
                var allIds = PokemonDatabase.All.Keys.Where(id => id != selectedPokemon).ToList();
                Shuffle(allIds);
                int count = Mathf.Min(selectedOpponents, allIds.Count);
                for (int i = 0; i < count; i++)
                {
                    float spacing = ArenaWidth / (count + 1);
                    float ex = -ArenaWidth / 2f + spacing * (i + 1);
                    var enemy = SpawnFighter(allIds[i], new Vector2(ex, ArenaHeight / 2f - 2.5f), false);
                    enemy.gameObject.AddComponent<AIController>();
                    enemies.Add(enemy);
                }
            }
        }
        else if (selectedMode == "2p")
        {
            player = SpawnFighter(selectedPokemon, new Vector2(-3, 0), true);
            player2 = SpawnFighter(selectedPokemonP2, new Vector2(3, 0), true);
            player2.isPlayer2 = true;
        }
        else if (selectedMode == "coop")
        {
            player = SpawnFighter(selectedPokemon, new Vector2(-2, -ArenaHeight / 2f + 2f), true);
            player2 = SpawnFighter(selectedPokemonP2, new Vector2(2, -ArenaHeight / 2f + 2f), true);
            player2.isPlayer2 = true;

            var allIds = PokemonDatabase.All.Keys
                .Where(id => id != selectedPokemon && id != selectedPokemonP2).ToList();
            Shuffle(allIds);
            int count = Mathf.Min(selectedOpponents, allIds.Count);
            for (int i = 0; i < count; i++)
            {
                float spacing = ArenaWidth / (count + 1);
                float ex = -ArenaWidth / 2f + spacing * (i + 1);
                var enemy = SpawnFighter(allIds[i], new Vector2(ex, ArenaHeight / 2f - 2.5f), false);
                enemy.gameObject.AddComponent<AIController>();
                enemies.Add(enemy);
            }
        }

        UIManager.Instance?.OnGameStart();
    }

    Fighter SpawnFighter(string pokemonId, Vector2 position, bool isPlayer)
    {
        var go = Instantiate(fighterPrefab, (Vector3)position, Quaternion.identity);
        go.SetActive(true);
        go.name = pokemonId + (isPlayer ? "_Player" : "_Enemy");
        var fighter = go.GetComponent<Fighter>();
        fighter.Init(pokemonId, isPlayer);
        return fighter;
    }

    // ============================================================
    // UPDATE
    // ============================================================

    void Update()
    {
        if (state != GameState.Playing) return;

        // --- Player 1 Input ---
        if (player != null && player.alive && player.stunTimer <= 0)
        {
            var input = TouchInputManager.Instance;
            if (input != null)
            {
                // Movement
                if (input.joystickActive)
                {
                    float speed = player.data.speed * (player.isDodging ? 2.5f : 1f) * 0.05f;
                    player.velocity = input.joystickDirection * speed;
                    if (input.joystickDirection.sqrMagnitude > 0.01f)
                        player.facing = input.joystickDirection.normalized;
                }

                // Attacks
                if (input.quickPressed) FireProjectile(player, "quick");
                if (input.specialPressed) FireProjectile(player, "special");
                if (input.ultimatePressed) FireProjectile(player, "ultimate");
                if (input.ultraPressed) FireUltraAttack(player);
                if (input.dodgePressed) player.Dodge();
            }
        }

        // --- Training mode: regen ---
        if (selectedMode == "training")
        {
            if (player != null)
            {
                player.hp = Mathf.Min(player.maxHp, player.hp + 2f * Time.deltaTime * 60f);
                player.alive = true;
            }
            foreach (var e in enemies)
            {
                if (e.isTrainingDummy)
                {
                    e.hp = Mathf.Min(e.maxHp, e.hp + 50f * Time.deltaTime * 60f);
                    e.alive = true;
                    e.gameObject.SetActive(true);
                }
            }
            return; // No win/loss in training
        }

        // --- Win/Loss Check ---
        CheckWinLoss();
    }

    void CheckWinLoss()
    {
        if (selectedMode == "2p")
        {
            if (player != null && !player.alive) EndGame("P2 Wins!");
            else if (player2 != null && !player2.alive) EndGame("P1 Wins!");
        }
        else
        {
            if (player != null && !player.alive)
                EndGame("Defeated!");
            else if (enemies.All(e => !e.alive))
                EndGame("Victory!");
        }
    }

    public void EndGame(string message)
    {
        state = GameState.GameOver;
        UIManager.Instance?.OnGameOver(message);
    }

    public void ReturnToMenu()
    {
        state = GameState.Menu;
        foreach (var f in FindObjectsOfType<Fighter>())
            if (f.gameObject != fighterPrefab) Destroy(f.gameObject);
        foreach (var p in FindObjectsOfType<Projectile>())
            if (p.gameObject != projectilePrefab) Destroy(p.gameObject);
        UIManager.Instance?.OnReturnToMenu();
    }

    // ============================================================
    // COMBAT
    // ============================================================

    public void FireProjectile(Fighter fighter, string attackType)
    {
        PokemonDatabase.AttackData attack = null;
        switch (attackType)
        {
            case "quick": attack = fighter.data.quick; break;
            case "special": attack = fighter.data.special; break;
            case "ultimate": attack = fighter.data.ultimate; break;
            case "ultra":
                FireUltraAttack(fighter);
                return;
        }
        if (attack == null || fighter.GetCooldown(attackType) > 0) return;

        fighter.SetCooldown(attackType, attack.cooldown);

        var go = Instantiate(projectilePrefab, Vector3.zero, Quaternion.identity);
        go.SetActive(true);
        go.name = $"Proj_{attack.name}";
        var proj = go.GetComponent<Projectile>();
        proj.Init(fighter, fighter.facing, attack, attackType);
    }

    void FireUltraAttack(Fighter fighter)
    {
        if (fighter.ultraCooldown > 0) return;
        var ultra = fighter.data.ultra;
        fighter.ultraCooldown = ultra.cooldown;

        // Get valid targets (opposing team only)
        var targets = GetAllFighters().Where(f =>
            f != fighter && f.alive &&
            ((fighter.isPlayer && !f.isPlayer) || (!fighter.isPlayer && f.isPlayer))
        ).ToList();

        if (fighter.pokemonId == "venusaur" || fighter.pokemonId == "gengar")
        {
            // AOE instant damage to all enemies
            foreach (var t in targets)
            {
                if (t.invincibleTimer > 0) continue;
                float mult = PokemonDatabase.GetTypeMultiplier(fighter.data.type, t.data.type);
                float dmg = ultra.damage * mult;
                t.hp -= dmg;
                t.flashTimer = 0.25f;
                t.stunTimer = Mathf.Max(t.stunTimer, 0.25f);
                SpawnDamageNumber(t.transform.position, dmg, mult > 1f);
            }
        }
        else if (fighter.pokemonId == "charizard")
        {
            // 3 fireballs spread
            float baseAngle = Mathf.Atan2(fighter.facing.y, fighter.facing.x);
            for (int i = -1; i <= 1; i++)
            {
                float a = baseAngle + i * 0.4f;
                Vector2 dir = new Vector2(Mathf.Cos(a), Mathf.Sin(a));
                var go = Instantiate(projectilePrefab, Vector3.zero, Quaternion.identity);
                go.SetActive(true);
                var proj = go.GetComponent<Projectile>();
                proj.Init(fighter, dir, ultra, "ultra");
            }
        }
        else if (fighter.pokemonId == "dragonite")
        {
            // 8 lightning bolts from above
            StartCoroutine(ThunderStorm(fighter, targets, ultra));
        }
        else if (fighter.pokemonId == "mewtwo")
        {
            // 5 homing orbs
            StartCoroutine(MindShatter(fighter, targets, ultra));
        }
        else if (fighter.pokemonId == "blastoise")
        {
            // Massive piercing laser
            var go = Instantiate(projectilePrefab, Vector3.zero, Quaternion.identity);
            go.SetActive(true);
            var proj = go.GetComponent<Projectile>();
            proj.Init(fighter, fighter.facing, ultra, "ultra");
        }
        else if (fighter.pokemonId == "quincy")
        {
            // 12 projectiles spiral
            StartCoroutine(Zoomies(fighter, ultra));
        }
    }

    IEnumerator ThunderStorm(Fighter fighter, List<Fighter> targets, PokemonDatabase.AttackData ultra)
    {
        for (int i = 0; i < 8; i++)
        {
            if (state != GameState.Playing) yield break;
            Fighter t = targets.Count > 0 ? targets[Random.Range(0, targets.Count)] : null;
            Vector2 pos = t != null ?
                (Vector2)t.transform.position + Random.insideUnitCircle * 2f :
                new Vector2(Random.Range(-ArenaWidth / 2f, ArenaWidth / 2f), ArenaHeight / 2f);

            var go = Instantiate(projectilePrefab, new Vector3(pos.x, ArenaHeight / 2f + 1f, 0), Quaternion.identity);
            go.SetActive(true);
            var proj = go.GetComponent<Projectile>();
            proj.Init(fighter, Vector2.down, ultra, "ultra");
            yield return new WaitForSeconds(0.12f);
        }
    }

    IEnumerator MindShatter(Fighter fighter, List<Fighter> targets, PokemonDatabase.AttackData ultra)
    {
        for (int i = 0; i < 5; i++)
        {
            if (state != GameState.Playing) yield break;
            float angle = (i / 5f) * Mathf.PI * 2f;
            Vector2 dir = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));

            var go = Instantiate(projectilePrefab, Vector3.zero, Quaternion.identity);
            go.SetActive(true);
            var proj = go.GetComponent<Projectile>();
            proj.Init(fighter, dir, ultra, "ultra");
            if (targets.Count > 0)
                proj.homingTarget = targets[i % targets.Count];
            yield return new WaitForSeconds(0.15f);
        }
    }

    IEnumerator Zoomies(Fighter fighter, PokemonDatabase.AttackData ultra)
    {
        for (int i = 0; i < 12; i++)
        {
            if (state != GameState.Playing) yield break;
            float angle = (i / 12f) * Mathf.PI * 2f;
            Vector2 dir = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));

            var go = Instantiate(projectilePrefab, Vector3.zero, Quaternion.identity);
            go.SetActive(true);
            var proj = go.GetComponent<Projectile>();
            proj.Init(fighter, dir, ultra, "ultra");
            yield return new WaitForSeconds(0.06f);
        }
    }

    // ============================================================
    // HELPERS
    // ============================================================

    public List<Fighter> GetAllFighters()
    {
        var list = new List<Fighter>();
        if (player != null) list.Add(player);
        if (player2 != null) list.Add(player2);
        list.AddRange(enemies);
        return list;
    }

    public void SpawnDamageNumber(Vector2 position, float damage, bool isSuper)
    {
        // Create floating damage text
        var go = new GameObject("DmgNum");
        go.transform.position = (Vector3)position + Vector3.up * 0.5f;
        var tm = go.AddComponent<TextMesh>();
        tm.text = Mathf.RoundToInt(damage).ToString();
        tm.characterSize = 0.15f;
        tm.fontSize = isSuper ? 48 : 36;
        tm.color = isSuper ? Color.yellow : Color.white;
        tm.alignment = TextAlignment.Center;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.GetComponent<MeshRenderer>().sortingOrder = 10;
        StartCoroutine(FloatAndDestroy(go));
    }

    IEnumerator FloatAndDestroy(GameObject go)
    {
        float t = 0;
        Vector3 start = go.transform.position;
        while (t < 0.8f)
        {
            t += Time.deltaTime;
            go.transform.position = start + Vector3.up * t * 2f;
            var c = go.GetComponent<TextMesh>().color;
            c.a = 1f - (t / 0.8f);
            go.GetComponent<TextMesh>().color = c;
            yield return null;
        }
        Destroy(go);
    }

    // Fisher-Yates shuffle
    public static void Shuffle<T>(List<T> list)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            (list[i], list[j]) = (list[j], list[i]);
        }
    }
}
