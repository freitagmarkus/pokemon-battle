using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Fighter entity — used for both players and AI enemies.
/// Attach to a GameObject with a SpriteRenderer and CircleCollider2D.
/// </summary>
public class Fighter : MonoBehaviour
{
    [Header("Identity")]
    public string pokemonId;
    public PokemonDatabase.PokemonData data;
    public bool isPlayer;
    public bool isPlayer2;
    public bool isTrainingDummy;
    public string playerName = "";

    [Header("State")]
    public float hp;
    public float maxHp;
    public bool alive = true;
    public Vector2 velocity;
    public Vector2 facing = Vector2.right;

    [Header("Cooldowns")]
    public float quickCooldown;
    public float specialCooldown;
    public float ultimateCooldown;
    public float ultraCooldown;

    [Header("Combat")]
    public float stunTimer;
    public float invincibleTimer;
    public float flashTimer;
    public bool isDodging;
    public float dodgeTimer;
    public float dodgeCooldown;

    [Header("Rendering")]
    public SpriteRenderer spriteRenderer;
    public float radius = 1f;

    private Color originalColor;

    public void Init(string id, bool player, bool player2 = false)
    {
        pokemonId = id;
        data = PokemonDatabase.All[id];
        isPlayer = player;
        isPlayer2 = player2;
        hp = data.hp;
        maxHp = data.hp;
        alive = true;
        velocity = Vector2.zero;
        facing = player ? Vector2.up : Vector2.down;
        ResetCooldowns();

        // Set up sprite
        spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer == null)
            spriteRenderer = gameObject.AddComponent<SpriteRenderer>();

        originalColor = data.color;
        spriteRenderer.color = data.color;

        // Download sprite from PokeAPI
        StartCoroutine(LoadSprite());

        // Scale
        transform.localScale = Vector3.one * (radius * 2f);
    }

    private IEnumerator LoadSprite()
    {
        string url = PokemonDatabase.GetSpriteUrl(data.dexNum);
        using (var www = UnityEngine.Networking.UnityWebRequestTexture.GetTexture(url))
        {
            yield return www.SendWebRequest();
            if (www.result == UnityEngine.Networking.UnityWebRequest.Result.Success)
            {
                var tex = UnityEngine.Networking.DownloadHandlerTexture.GetContent(www);
                var sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height),
                    new Vector2(0.5f, 0.5f), 100f);
                spriteRenderer.sprite = sprite;
                spriteRenderer.color = Color.white;
                originalColor = Color.white;
            }
        }
    }

    public void ResetCooldowns()
    {
        quickCooldown = 0;
        specialCooldown = 0;
        ultimateCooldown = 0;
        ultraCooldown = 0;
        dodgeCooldown = 0;
        stunTimer = 0;
        invincibleTimer = 0;
        flashTimer = 0;
        isDodging = false;
        dodgeTimer = 0;
    }

    void Update()
    {
        if (!alive) return;
        float dt = Time.deltaTime;

        // Cooldowns
        if (quickCooldown > 0) quickCooldown -= dt;
        if (specialCooldown > 0) specialCooldown -= dt;
        if (ultimateCooldown > 0) ultimateCooldown -= dt;
        if (ultraCooldown > 0) ultraCooldown -= dt;
        if (dodgeCooldown > 0) dodgeCooldown -= dt;
        if (stunTimer > 0) stunTimer -= dt;
        if (invincibleTimer > 0) invincibleTimer -= dt;

        // Dodge timer
        if (isDodging)
        {
            dodgeTimer -= dt;
            if (dodgeTimer <= 0)
                isDodging = false;
        }

        // Flash effect (hit feedback)
        if (flashTimer > 0)
        {
            flashTimer -= dt;
            spriteRenderer.color = flashTimer > 0 ? Color.white : originalColor;
        }

        // Move
        transform.position += (Vector3)(velocity * dt * 60f);

        // Arena bounds
        Vector2 pos = transform.position;
        float arenaW = GameManager.ArenaWidth / 2f;
        float arenaH = GameManager.ArenaHeight / 2f;
        pos.x = Mathf.Clamp(pos.x, -arenaW + radius, arenaW - radius);
        pos.y = Mathf.Clamp(pos.y, -arenaH + radius, arenaH - radius);
        transform.position = pos;

        // Friction when not moving
        velocity *= 0.92f;

        // Death check
        if (hp <= 0 && !isTrainingDummy)
        {
            hp = 0;
            alive = false;
            gameObject.SetActive(false);
        }
    }

    public float GetCooldown(string attackType)
    {
        switch (attackType)
        {
            case "quick": return quickCooldown;
            case "special": return specialCooldown;
            case "ultimate": return ultimateCooldown;
            case "ultra": return ultraCooldown;
            default: return 0;
        }
    }

    public void SetCooldown(string attackType, float value)
    {
        switch (attackType)
        {
            case "quick": quickCooldown = value; break;
            case "special": specialCooldown = value; break;
            case "ultimate": ultimateCooldown = value; break;
            case "ultra": ultraCooldown = value; break;
        }
    }

    public void TakeDamage(float damage, Fighter attacker)
    {
        if (!alive || invincibleTimer > 0) return;

        // Friendly fire check: only damage the opposing team
        if (attacker != null)
        {
            if (attacker.isPlayer && isPlayer && attacker != this) return; // no player-on-player (co-op)
            if (!attacker.isPlayer && !isPlayer) return; // no enemy-on-enemy
        }

        float mult = PokemonDatabase.GetTypeMultiplier(attacker.data.type, data.type);
        float finalDmg = damage * mult;
        hp -= finalDmg;
        flashTimer = 0.25f;
        stunTimer = Mathf.Max(stunTimer, 0.08f);

        // Spawn damage number
        GameManager.Instance.SpawnDamageNumber(transform.position, finalDmg, mult > 1f);
    }

    public void Dodge()
    {
        if (dodgeCooldown > 0 || isDodging) return;
        isDodging = true;
        dodgeTimer = 0.25f;
        invincibleTimer = 0.25f;
        dodgeCooldown = 0.75f;
        velocity = facing * data.speed * 4f * 0.05f;
    }
}
