using UnityEngine;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Enemy AI — chase, attack, flee, dodge behaviors.
/// Attach to enemy Fighter GameObjects.
/// </summary>
public class AIController : MonoBehaviour
{
    public Fighter fighter;

    private enum AIState { Idle, Chase, Attack, Flee, Dodge }
    private AIState state = AIState.Idle;
    private float stateTimer;
    private float aiTimer;
    private Fighter target;

    private float accuracy = 0.7f;
    private float reactionTime = 0.3f;
    private float aggressiveness = 0.6f;

    void Start()
    {
        fighter = GetComponent<Fighter>();
        SetDifficulty(GameManager.Instance.currentDifficulty);
    }

    public void SetDifficulty(string diff)
    {
        switch (diff)
        {
            case "baby":
                accuracy = 0.3f; reactionTime = 0.8f; aggressiveness = 0.2f; break;
            case "easy":
                accuracy = 0.5f; reactionTime = 0.5f; aggressiveness = 0.4f; break;
            case "medium":
                accuracy = 0.7f; reactionTime = 0.3f; aggressiveness = 0.6f; break;
            case "hard":
                accuracy = 0.9f; reactionTime = 0.15f; aggressiveness = 0.85f; break;
        }
    }

    void Update()
    {
        if (!fighter.alive || fighter.isPlayer || fighter.isTrainingDummy) return;
        if (fighter.stunTimer > 0) return;

        float dt = Time.deltaTime;
        aiTimer -= dt;
        stateTimer -= dt;
        float speed = fighter.data.speed * 0.05f;

        // Pick target (nearest player)
        var players = GameManager.Instance.GetAllFighters()
            .Where(f => f != fighter && f.alive && f.isPlayer).ToList();
        if (players.Count == 0) return;

        target = players.OrderBy(p => Vector2.Distance(transform.position, p.transform.position)).First();
        Vector2 toTarget = (Vector2)target.transform.position - (Vector2)transform.position;
        float dist = toTarget.magnitude;

        // State transitions
        if (stateTimer <= 0)
        {
            float hpPct = fighter.hp / fighter.maxHp;
            if (hpPct < 0.25f && Random.value < 0.6f)
            {
                state = AIState.Flee;
                stateTimer = Random.Range(1f, 2f);
            }
            else if (dist < 3f && Random.value < aggressiveness)
            {
                state = AIState.Attack;
                stateTimer = Random.Range(0.8f, 1.5f);
            }
            else
            {
                state = AIState.Chase;
                stateTimer = Random.Range(1f, 2.5f);
            }
        }

        // Execute state
        switch (state)
        {
            case AIState.Chase:
                if (dist > 1.5f)
                {
                    fighter.velocity = toTarget.normalized * speed;
                    fighter.facing = toTarget.normalized;
                }
                // Shoot while approaching
                if (aiTimer <= 0 && dist < 6f && Random.value < accuracy)
                {
                    string atkType = Random.value < 0.7f ? "quick" : "special";
                    GameManager.Instance.FireProjectile(fighter, atkType);
                    aiTimer = reactionTime;
                }
                break;

            case AIState.Attack:
                // Stand and shoot
                fighter.facing = toTarget.normalized;
                if (aiTimer <= 0 && Random.value < accuracy)
                {
                    float roll = Random.value;
                    string atkType;
                    if (roll < 0.05f && fighter.ultraCooldown <= 0)
                        atkType = "ultra";
                    else if (roll < 0.15f && fighter.ultimateCooldown <= 0)
                        atkType = "ultimate";
                    else if (roll < 0.35f)
                        atkType = "special";
                    else
                        atkType = "quick";
                    GameManager.Instance.FireProjectile(fighter, atkType);
                    aiTimer = reactionTime;
                }
                break;

            case AIState.Flee:
                fighter.velocity = -toTarget.normalized * speed * 0.8f;
                fighter.facing = toTarget.normalized; // face target while fleeing
                // Still shoot while fleeing
                if (aiTimer <= 0 && Random.value < accuracy * 0.5f)
                {
                    GameManager.Instance.FireProjectile(fighter, "quick");
                    aiTimer = reactionTime;
                }
                break;
        }

        // Wall avoidance
        Vector2 pos = transform.position;
        float margin = 2f;
        float arenaW = GameManager.ArenaWidth / 2f;
        float arenaH = GameManager.ArenaHeight / 2f;
        float wallForce = speed * 0.8f;

        if (pos.x < -arenaW + margin) fighter.velocity += Vector2.right * wallForce * (1f - (pos.x + arenaW) / margin);
        if (pos.x > arenaW - margin) fighter.velocity += Vector2.left * wallForce * (1f - (arenaW - pos.x) / margin);
        if (pos.y < -arenaH + margin) fighter.velocity += Vector2.up * wallForce * (1f - (pos.y + arenaH) / margin);
        if (pos.y > arenaH - margin) fighter.velocity += Vector2.down * wallForce * (1f - (arenaH - pos.y) / margin);

        // Corner escape
        bool nearWallX = Mathf.Abs(pos.x) > arenaW - fighter.radius - 0.1f;
        bool nearWallY = Mathf.Abs(pos.y) > arenaH - fighter.radius - 0.1f;
        if (nearWallX && nearWallY)
        {
            state = AIState.Chase;
            stateTimer = 3f;
        }
    }
}
