using UnityEngine;

/// <summary>
/// Touch input for Board.fun — virtual joystick + attack buttons.
/// Works with Unity's Input.touches, which maps directly to Board's touchscreen.
/// </summary>
public class TouchInputManager : MonoBehaviour
{
    public static TouchInputManager Instance { get; private set; }

    [Header("Joystick Output")]
    public Vector2 joystickDirection; // -1 to 1 for each axis
    public bool joystickActive;

    [Header("Attack Buttons")]
    public bool quickPressed;
    public bool specialPressed;
    public bool ultimatePressed;
    public bool ultraPressed;
    public bool dodgePressed;

    // Joystick internals
    private int joystickTouchId = -1;
    private Vector2 joystickOrigin;
    private float joystickMaxRadius = 80f; // pixels

    // Button zones (screen-space rects, set in Start)
    private Rect quickRect;
    private Rect specialRect;
    private Rect ultimateRect;
    private Rect ultraRect;
    private Rect dodgeRect;

    // UI references (created dynamically)
    private GameObject joystickBase;
    private GameObject joystickKnob;
    private Canvas uiCanvas;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        // Create UI canvas for touch controls
        CreateTouchUI();
        LayoutButtons();
    }

    void CreateTouchUI()
    {
        // Create canvas
        var canvasGO = new GameObject("TouchCanvas");
        uiCanvas = canvasGO.AddComponent<Canvas>();
        uiCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        uiCanvas.sortingOrder = 100;
        canvasGO.AddComponent<UnityEngine.UI.CanvasScaler>().uiScaleMode =
            UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasGO.AddComponent<UnityEngine.UI.GraphicRaycaster>();

        // Joystick base
        joystickBase = CreateCircleUI(canvasGO.transform, "JoystickBase",
            new Vector2(140, 140), 150, new Color(1, 1, 1, 0.15f));
        joystickBase.GetComponent<RectTransform>().anchorMin = new Vector2(0, 0);
        joystickBase.GetComponent<RectTransform>().anchorMax = new Vector2(0, 0);
        joystickBase.GetComponent<RectTransform>().anchoredPosition = new Vector2(140, 140);

        // Joystick knob
        joystickKnob = CreateCircleUI(joystickBase.transform, "JoystickKnob",
            Vector2.zero, 60, new Color(1, 1, 1, 0.4f));

        // Attack buttons
        CreateButton(canvasGO.transform, "Quick", "J\nQuick",
            new Color(0.9f, 0.3f, 0.24f, 0.6f), new Vector2(-200, 60));
        CreateButton(canvasGO.transform, "Special", "K\nSpecial",
            new Color(0.2f, 0.6f, 0.86f, 0.6f), new Vector2(-130, 130));
        CreateButton(canvasGO.transform, "Ultimate", "L\nUlt",
            new Color(0.61f, 0.35f, 0.71f, 0.6f), new Vector2(-60, 60));
        CreateButton(canvasGO.transform, "Ultra", "U\nUltra",
            new Color(0.95f, 0.77f, 0.06f, 0.6f), new Vector2(-260, 130));
        CreateButton(canvasGO.transform, "Dodge", "⚡\nDodge",
            new Color(0.18f, 0.8f, 0.44f, 0.6f), new Vector2(-200, 200));
    }

    GameObject CreateCircleUI(Transform parent, string name, Vector2 pos, float size, Color color)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.sizeDelta = new Vector2(size, size);
        rt.anchoredPosition = pos;
        var img = go.AddComponent<UnityEngine.UI.Image>();
        img.color = color;
        // Make it circular by using a sprite mask or just leaving it as-is
        return go;
    }

    void CreateButton(Transform parent, string name, string label, Color color, Vector2 offset)
    {
        var go = new GameObject("Btn_" + name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(1, 0);
        rt.anchorMax = new Vector2(1, 0);
        rt.sizeDelta = new Vector2(70, 70);
        rt.anchoredPosition = offset;
        var img = go.AddComponent<UnityEngine.UI.Image>();
        img.color = color;

        // Label
        var textGO = new GameObject("Label");
        textGO.transform.SetParent(go.transform, false);
        var textRT = textGO.AddComponent<RectTransform>();
        textRT.anchorMin = Vector2.zero;
        textRT.anchorMax = Vector2.one;
        textRT.offsetMin = Vector2.zero;
        textRT.offsetMax = Vector2.zero;
        var text = textGO.AddComponent<UnityEngine.UI.Text>();
        text.text = label;
        text.alignment = TextAnchor.MiddleCenter;
        text.color = Color.white;
        text.fontSize = 12;
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
    }

    void LayoutButtons()
    {
        // Calculate button rects in screen space for touch detection
        float bSize = 70;
        float sw = Screen.width;
        float sh = Screen.height;

        quickRect = new Rect(sw - 250, 25, bSize, bSize);
        specialRect = new Rect(sw - 180, 95, bSize, bSize);
        ultimateRect = new Rect(sw - 110, 25, bSize, bSize);
        ultraRect = new Rect(sw - 310, 95, bSize, bSize);
        dodgeRect = new Rect(sw - 250, 165, bSize, bSize);
    }

    void Update()
    {
        // Reset one-frame states
        quickPressed = false;
        specialPressed = false;
        ultimatePressed = false;
        ultraPressed = false;
        dodgePressed = false;

        // Also accept keyboard input (for testing on PC)
        if (UnityEngine.Input.GetKey(KeyCode.J)) quickPressed = true;
        if (UnityEngine.Input.GetKey(KeyCode.K)) specialPressed = true;
        if (UnityEngine.Input.GetKey(KeyCode.L)) ultimatePressed = true;
        if (UnityEngine.Input.GetKey(KeyCode.U)) ultraPressed = true;
        if (UnityEngine.Input.GetKey(KeyCode.Space)) dodgePressed = true;

        // Keyboard movement (for PC testing)
        float kx = 0, ky = 0;
        if (UnityEngine.Input.GetKey(KeyCode.A) || UnityEngine.Input.GetKey(KeyCode.LeftArrow)) kx -= 1;
        if (UnityEngine.Input.GetKey(KeyCode.D) || UnityEngine.Input.GetKey(KeyCode.RightArrow)) kx += 1;
        if (UnityEngine.Input.GetKey(KeyCode.W) || UnityEngine.Input.GetKey(KeyCode.UpArrow)) ky += 1;
        if (UnityEngine.Input.GetKey(KeyCode.S) || UnityEngine.Input.GetKey(KeyCode.DownArrow)) ky -= 1;
        if (kx != 0 || ky != 0)
        {
            joystickDirection = new Vector2(kx, ky).normalized;
            joystickActive = true;
        }

        // Process touches
        for (int i = 0; i < UnityEngine.Input.touchCount; i++)
        {
            Touch t = UnityEngine.Input.GetTouch(i);

            // Left half = joystick
            if (t.position.x < Screen.width * 0.4f)
            {
                HandleJoystickTouch(t);
            }
            // Right half = buttons
            else
            {
                HandleButtonTouch(t);
            }
        }

        // Update joystick knob visual
        if (joystickKnob != null)
        {
            float visualRange = 35f;
            joystickKnob.GetComponent<RectTransform>().anchoredPosition =
                joystickActive ? joystickDirection * visualRange : Vector2.zero;
        }
    }

    void HandleJoystickTouch(Touch t)
    {
        switch (t.phase)
        {
            case TouchPhase.Began:
                joystickTouchId = t.fingerId;
                joystickOrigin = t.position;
                joystickActive = true;
                break;

            case TouchPhase.Moved:
            case TouchPhase.Stationary:
                if (t.fingerId == joystickTouchId)
                {
                    Vector2 delta = t.position - joystickOrigin;
                    float dist = delta.magnitude;
                    if (dist > joystickMaxRadius)
                        delta = delta.normalized * joystickMaxRadius;
                    joystickDirection = delta / joystickMaxRadius;
                    joystickActive = true;
                }
                break;

            case TouchPhase.Ended:
            case TouchPhase.Canceled:
                if (t.fingerId == joystickTouchId)
                {
                    joystickTouchId = -1;
                    joystickDirection = Vector2.zero;
                    joystickActive = false;
                }
                break;
        }
    }

    void HandleButtonTouch(Touch t)
    {
        if (t.phase == TouchPhase.Began || t.phase == TouchPhase.Moved || t.phase == TouchPhase.Stationary)
        {
            Vector2 pos = t.position;
            if (quickRect.Contains(pos)) quickPressed = true;
            if (specialRect.Contains(pos)) specialPressed = true;
            if (ultimateRect.Contains(pos)) ultimatePressed = true;
            if (ultraRect.Contains(pos)) ultraPressed = true;
            if (dodgeRect.Contains(pos)) dodgePressed = true;
        }
    }
}
