using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// All Pokémon definitions: stats, attacks, type matchups.
/// </summary>
public static class PokemonDatabase
{
    public enum PokemonType { Fire, Water, Grass, Electric, Ghost, Psychic, Fairy }

    [System.Serializable]
    public class AttackData
    {
        public string name;
        public float damage;
        public float cooldown; // seconds
        public float speed;
        public float size;
        public float lifetime;
        public Color color;
        public bool piercing;
        public float aoe;
        public bool isUltra;
        public int ultraProjectiles; // for multi-projectile ultras
        public float spreadAngle;
    }

    [System.Serializable]
    public class PokemonData
    {
        public string id;
        public string name;
        public PokemonType type;
        public int dexNum;
        public Color color;
        public float hp;
        public float speed;
        public AttackData quick;
        public AttackData special;
        public AttackData ultimate;
        public AttackData ultra;
        public PokemonType strongVs;
        public PokemonType weakVs;
    }

    public static readonly Dictionary<string, PokemonData> All = new Dictionary<string, PokemonData>
    {
        ["charizard"] = new PokemonData {
            id = "charizard", name = "Charizard", type = PokemonType.Fire, dexNum = 6,
            color = new Color(0.89f, 0.35f, 0.13f), hp = 360, speed = 4.5f,
            strongVs = PokemonType.Grass, weakVs = PokemonType.Water,
            quick = new AttackData { name = "Ember", damage = 18, cooldown = 0.4f, speed = 8, size = 0.3f, lifetime = 0.67f, color = new Color(1f, 0.42f, 0.21f) },
            special = new AttackData { name = "Flamethrower", damage = 40, cooldown = 1.2f, speed = 6, size = 0.55f, lifetime = 1f, color = new Color(1f, 0.27f, 0f), piercing = true },
            ultimate = new AttackData { name = "Fire Blast", damage = 80, cooldown = 4f, speed = 5, size = 0.9f, lifetime = 1.17f, color = Color.red, aoe = 1.8f },
            ultra = new AttackData { name = "Inferno Burst", damage = 55, cooldown = 6f, speed = 7, size = 0.65f, lifetime = 0.92f, color = new Color(1f, 0.27f, 0f), isUltra = true, ultraProjectiles = 3, spreadAngle = 23f },
        },
        ["blastoise"] = new PokemonData {
            id = "blastoise", name = "Blastoise", type = PokemonType.Water, dexNum = 9,
            color = new Color(0.16f, 0.5f, 0.73f), hp = 420, speed = 3.5f,
            strongVs = PokemonType.Fire, weakVs = PokemonType.Grass,
            quick = new AttackData { name = "Water Gun", damage = 16, cooldown = 0.45f, speed = 7, size = 0.3f, lifetime = 0.75f, color = new Color(0.2f, 0.6f, 0.86f) },
            special = new AttackData { name = "Hydro Pump", damage = 45, cooldown = 1.4f, speed = 5, size = 0.6f, lifetime = 1.08f, color = new Color(0.14f, 0.44f, 0.64f), piercing = true },
            ultimate = new AttackData { name = "Hydro Cannon", damage = 90, cooldown = 4.5f, speed = 4, size = 1.05f, lifetime = 1.33f, color = new Color(0.1f, 0.32f, 0.46f), aoe = 2.1f },
            ultra = new AttackData { name = "Tidal Laser", damage = 120, cooldown = 7f, speed = 14, size = 1.2f, lifetime = 1.33f, color = new Color(0f, 0.75f, 1f), isUltra = true, piercing = true },
        },
        ["venusaur"] = new PokemonData {
            id = "venusaur", name = "Venusaur", type = PokemonType.Grass, dexNum = 3,
            color = new Color(0.15f, 0.68f, 0.38f), hp = 400, speed = 3.8f,
            strongVs = PokemonType.Water, weakVs = PokemonType.Fire,
            quick = new AttackData { name = "Razor Leaf", damage = 15, cooldown = 0.35f, speed = 9, size = 0.3f, lifetime = 0.58f, color = new Color(0.18f, 0.8f, 0.44f) },
            special = new AttackData { name = "Solar Beam", damage = 50, cooldown = 1.5f, speed = 5, size = 0.65f, lifetime = 1.17f, color = new Color(0.56f, 0.93f, 0.56f), piercing = true },
            ultimate = new AttackData { name = "Frenzy Plant", damage = 85, cooldown = 4.2f, speed = 4, size = 1f, lifetime = 1.33f, color = new Color(0.1f, 0.5f, 0.2f), aoe = 1.95f },
            ultra = new AttackData { name = "Bloom Doom", damage = 100, cooldown = 6.5f, isUltra = true, color = new Color(0f, 1f, 0.53f) }, // AOE instant
        },
        ["dragonite"] = new PokemonData {
            id = "dragonite", name = "Dragonite", type = PokemonType.Electric, dexNum = 149,
            color = new Color(0.95f, 0.77f, 0.06f), hp = 380, speed = 5f,
            strongVs = PokemonType.Water, weakVs = PokemonType.Grass,
            quick = new AttackData { name = "Thunder Punch", damage = 20, cooldown = 0.38f, speed = 9, size = 0.35f, lifetime = 0.5f, color = Color.yellow },
            special = new AttackData { name = "Thunderbolt", damage = 42, cooldown = 1.3f, speed = 10, size = 0.5f, lifetime = 0.83f, color = new Color(1f, 0.84f, 0f), piercing = true },
            ultimate = new AttackData { name = "Draco Meteor", damage = 95, cooldown = 4.8f, speed = 3, size = 1.2f, lifetime = 1.5f, color = new Color(1f, 0.65f, 0f), aoe = 2.4f },
            ultra = new AttackData { name = "Thunder Storm", damage = 35, cooldown = 6f, isUltra = true, ultraProjectiles = 8, color = Color.yellow },
        },
        ["gengar"] = new PokemonData {
            id = "gengar", name = "Gengar", type = PokemonType.Ghost, dexNum = 94,
            color = new Color(0.44f, 0.24f, 0.58f), hp = 320, speed = 5.5f,
            strongVs = PokemonType.Psychic, weakVs = PokemonType.Electric,
            quick = new AttackData { name = "Shadow Ball", damage = 22, cooldown = 0.42f, speed = 8, size = 0.35f, lifetime = 0.67f, color = new Color(0.61f, 0.35f, 0.71f) },
            special = new AttackData { name = "Dark Pulse", damage = 38, cooldown = 1.1f, speed = 7, size = 0.5f, lifetime = 1f, color = new Color(0.29f, 0.08f, 0.35f), piercing = true },
            ultimate = new AttackData { name = "Hex", damage = 70, cooldown = 3.8f, speed = 6, size = 0.9f, lifetime = 1.17f, color = new Color(0.5f, 0f, 0.5f), aoe = 1.65f },
            ultra = new AttackData { name = "Nightmare", damage = 80, cooldown = 6f, isUltra = true, color = new Color(0.61f, 0.35f, 0.71f) }, // AOE instant
        },
        ["mewtwo"] = new PokemonData {
            id = "mewtwo", name = "Mewtwo", type = PokemonType.Psychic, dexNum = 150,
            color = new Color(0.64f, 0.42f, 0.81f), hp = 350, speed = 5.2f,
            strongVs = PokemonType.Grass, weakVs = PokemonType.Ghost,
            quick = new AttackData { name = "Psybeam", damage = 19, cooldown = 0.4f, speed = 9, size = 0.3f, lifetime = 0.58f, color = new Color(0.91f, 0.26f, 0.58f) },
            special = new AttackData { name = "Psychic", damage = 44, cooldown = 1.3f, speed = 6, size = 0.6f, lifetime = 1.17f, color = new Color(0.69f, 0.27f, 0.85f), piercing = true },
            ultimate = new AttackData { name = "Psystrike", damage = 88, cooldown = 4.5f, speed = 5, size = 1.05f, lifetime = 1.33f, color = new Color(0.56f, 0.15f, 0.67f), aoe = 2f },
            ultra = new AttackData { name = "Mind Shatter", damage = 40, cooldown = 6.5f, isUltra = true, ultraProjectiles = 5, color = new Color(0.91f, 0.26f, 0.58f) }, // homing
        },
        ["quincy"] = new PokemonData {
            id = "quincy", name = "Quincy", type = PokemonType.Fairy, dexNum = 39,
            color = new Color(1f, 0.75f, 0.8f), hp = 440, speed = 3.2f,
            strongVs = PokemonType.Ghost, weakVs = PokemonType.Fire,
            quick = new AttackData { name = "Sweet Kiss", damage = 14, cooldown = 0.5f, speed = 7, size = 0.35f, lifetime = 0.75f, color = new Color(1f, 0.71f, 0.76f) },
            special = new AttackData { name = "Dazzle Beam", damage = 36, cooldown = 1.4f, speed = 5, size = 0.55f, lifetime = 1.08f, color = new Color(0.99f, 0.84f, 0.65f), piercing = true },
            ultimate = new AttackData { name = "Moonblast", damage = 75, cooldown = 4f, speed = 4, size = 1f, lifetime = 1.33f, color = new Color(0.99f, 0.88f, 0.88f), aoe = 1.95f },
            ultra = new AttackData { name = "Zoomies", damage = 25, cooldown = 5.5f, isUltra = true, ultraProjectiles = 12, piercing = true, color = new Color(1f, 0.92f, 0.65f) },
        },
    };

    /// <summary>
    /// Type effectiveness chart. Returns damage multiplier.
    /// </summary>
    public static float GetTypeMultiplier(PokemonType attackerType, PokemonType defenderType)
    {
        // Simplified type chart
        if (attackerType == PokemonType.Fire && defenderType == PokemonType.Grass) return 1.5f;
        if (attackerType == PokemonType.Fire && defenderType == PokemonType.Water) return 0.7f;
        if (attackerType == PokemonType.Water && defenderType == PokemonType.Fire) return 1.5f;
        if (attackerType == PokemonType.Water && defenderType == PokemonType.Grass) return 0.7f;
        if (attackerType == PokemonType.Grass && defenderType == PokemonType.Water) return 1.5f;
        if (attackerType == PokemonType.Grass && defenderType == PokemonType.Fire) return 0.7f;
        if (attackerType == PokemonType.Electric && defenderType == PokemonType.Water) return 1.5f;
        if (attackerType == PokemonType.Ghost && defenderType == PokemonType.Psychic) return 1.5f;
        if (attackerType == PokemonType.Psychic && defenderType == PokemonType.Grass) return 1.5f;
        if (attackerType == PokemonType.Fairy && defenderType == PokemonType.Ghost) return 1.5f;
        if (attackerType == PokemonType.Fairy && defenderType == PokemonType.Psychic) return 1.5f;
        return 1f;
    }

    /// <summary>
    /// Sprite URL for a Pokémon (downloads at runtime).
    /// </summary>
    public static string GetSpriteUrl(int dexNum)
    {
        return $"https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/{dexNum}.png";
    }
}
