using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// UI manager — menu, HUD, game over screens.
/// Creates all UI programmatically (no scene setup needed).
/// </summary>
public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    // UI Panels
    private GameObject menuPanel;
    private GameObject hudPanel;
    private GameObject gameOverPanel;
    private Canvas mainCanvas;

    // Menu elements
    private Dictionary<string, Button> modeButtons = new Dictionary<string, Button>();
    private Dictionary<string, Button> pokemonButtons = new Dictionary<string, Button>();
    private Dictionary<string, Button> diffButtons = new Dictionary<string, Button>();
    private Button startButton;
    private Text selectedLabel;

    // HUD elements
    private Slider playerHpBar;
    private Text playerNameText;
    private List<Slider> enemyHpBars = new List<Slider>();

    // Game over
    private Text gameOverTitle;
    private Text gameOverMessage;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        CreateCanvas();
        CreateMenuUI();
        CreateHUD();
        CreateGameOverUI();
        ShowMenu();
    }

    // ============================================================
    // CANVAS
    // ============================================================

    void CreateCanvas()
    {
        var go = new GameObject("MainCanvas");
        go.transform.SetParent(transform);
        mainCanvas = go.AddComponent<Canvas>();
        mainCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        mainCanvas.sortingOrder = 50;
        var scaler = go.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        go.AddComponent<GraphicRaycaster>();
    }

    // ============================================================
    // MENU
    // ============================================================

    void CreateMenuUI()
    {
        menuPanel = CreatePanel("MenuPanel", new Color(0.04f, 0.04f, 0.14f, 0.95f));

        float yPos = 400;

        // Title
        CreateText(menuPanel.transform, "⚔️ Pokémon Battle Arena", 42, new Vector2(0, yPos),
            new Color(0.91f, 0.27f, 0.38f));
        yPos -= 70;

        // Mode buttons
        CreateText(menuPanel.transform, "Mode", 24, new Vector2(0, yPos), Color.white);
        yPos -= 45;

        string[] modes = { "1p:🎮 1 Player", "2p:👥 2P PvP", "coop:🤝 Co-op", "training:🎯 Training" };
        float modeX = -300;
        foreach (var m in modes)
        {
            var parts = m.Split(':');
            var btn = CreateButton(menuPanel.transform, parts[1], new Vector2(modeX, yPos), 200, 45);
            string mode = parts[0];
            btn.onClick.AddListener(() => SelectMode(mode));
            modeButtons[mode] = btn;
            modeX += 210;
        }
        yPos -= 80;

        // Pokémon select
        selectedLabel = CreateText(menuPanel.transform, "Choose your fighter!", 22, new Vector2(0, yPos), Color.white);
        yPos -= 55;

        float pokeX = -450;
        foreach (var kvp in PokemonDatabase.All)
        {
            var btn = CreateButton(menuPanel.transform, kvp.Value.name,
                new Vector2(pokeX, yPos), 140, 50, kvp.Value.color);
            string id = kvp.Key;
            btn.onClick.AddListener(() => SelectPokemon(id));
            pokemonButtons[id] = btn;
            pokeX += 150;
        }
        yPos -= 80;

        // Difficulty
        CreateText(menuPanel.transform, "Difficulty", 22, new Vector2(0, yPos), Color.white);
        yPos -= 45;
        string[] diffs = { "baby:👶 Baby", "easy:🟢 Easy", "medium:🟡 Medium", "hard:🔴 Hard" };
        float diffX = -250;
        foreach (var d in diffs)
        {
            var parts = d.Split(':');
            var btn = CreateButton(menuPanel.transform, parts[1], new Vector2(diffX, yPos), 160, 45);
            string diff = parts[0];
            btn.onClick.AddListener(() => SelectDifficulty(diff));
            diffButtons[diff] = btn;
            diffX += 170;
        }
        yPos -= 90;

        // Start button
        startButton = CreateButton(menuPanel.transform, "⚔️ START BATTLE",
            new Vector2(0, yPos), 300, 60, new Color(0.91f, 0.27f, 0.38f));
        startButton.onClick.AddListener(OnStartClicked);
        startButton.interactable = false;

        // Default selections
        SelectMode("1p");
        SelectDifficulty("medium");
    }

    void SelectMode(string mode)
    {
        GameManager.Instance.selectedMode = mode;
        foreach (var kvp in modeButtons)
            SetButtonSelected(kvp.Value, kvp.Key == mode);
        UpdateStartButton();
    }

    void SelectPokemon(string id)
    {
        var gm = GameManager.Instance;
        if (gm.selectedMode == "2p" || gm.selectedMode == "coop")
        {
            if (gm.selectedPokemon == null)
            {
                gm.selectedPokemon = id;
                selectedLabel.text = $"P1: {PokemonDatabase.All[id].name} ✓  Now pick P2!";
            }
            else if (gm.selectedPokemonP2 == null && id != gm.selectedPokemon)
            {
                gm.selectedPokemonP2 = id;
                selectedLabel.text = $"P1: {PokemonDatabase.All[gm.selectedPokemon].name}  P2: {PokemonDatabase.All[id].name}";
            }
            else
            {
                gm.selectedPokemon = id;
                gm.selectedPokemonP2 = null;
                selectedLabel.text = $"P1: {PokemonDatabase.All[id].name} ✓  Now pick P2!";
            }
        }
        else
        {
            gm.selectedPokemon = id;
            selectedLabel.text = $"Selected: {PokemonDatabase.All[id].name}";
        }

        foreach (var kvp in pokemonButtons)
        {
            bool sel = kvp.Key == gm.selectedPokemon || kvp.Key == gm.selectedPokemonP2;
            SetButtonSelected(kvp.Value, sel);
        }
        UpdateStartButton();
    }

    void SelectDifficulty(string diff)
    {
        GameManager.Instance.currentDifficulty = diff;
        foreach (var kvp in diffButtons)
            SetButtonSelected(kvp.Value, kvp.Key == diff);
    }

    void UpdateStartButton()
    {
        var gm = GameManager.Instance;
        bool ready = gm.selectedPokemon != null;
        if (gm.selectedMode == "2p" || gm.selectedMode == "coop")
            ready = gm.selectedPokemon != null && gm.selectedPokemonP2 != null;
        startButton.interactable = ready;
    }

    void OnStartClicked()
    {
        GameManager.Instance.StartGame();
    }

    // ============================================================
    // HUD
    // ============================================================

    void CreateHUD()
    {
        hudPanel = CreatePanel("HUDPanel", Color.clear);
        hudPanel.SetActive(false);

        // Player HP bar
        playerHpBar = CreateHpBar(hudPanel.transform, new Vector2(-700, 470), 300, "Player");
        playerNameText = playerHpBar.GetComponentInChildren<Text>();
    }

    public void OnGameStart()
    {
        menuPanel.SetActive(false);
        hudPanel.SetActive(true);
        gameOverPanel.SetActive(false);
        UpdateHUD();
    }

    void UpdateHUD()
    {
        var gm = GameManager.Instance;
        if (gm.player != null)
        {
            playerHpBar.maxValue = gm.player.maxHp;
            playerHpBar.value = gm.player.hp;
        }
    }

    void Update()
    {
        if (GameManager.Instance.state == GameManager.GameState.Playing)
            UpdateHUD();
    }

    // ============================================================
    // GAME OVER
    // ============================================================

    void CreateGameOverUI()
    {
        gameOverPanel = CreatePanel("GameOverPanel", new Color(0, 0, 0, 0.8f));
        gameOverPanel.SetActive(false);

        gameOverTitle = CreateText(gameOverPanel.transform, "GAME OVER", 56,
            new Vector2(0, 80), Color.white);
        gameOverMessage = CreateText(gameOverPanel.transform, "", 28,
            new Vector2(0, 0), new Color(0.8f, 0.8f, 0.8f));

        var btn = CreateButton(gameOverPanel.transform, "🔄 Play Again",
            new Vector2(0, -100), 250, 55, new Color(0.91f, 0.27f, 0.38f));
        btn.onClick.AddListener(() => GameManager.Instance.ReturnToMenu());
    }

    public void OnGameOver(string message)
    {
        gameOverPanel.SetActive(true);
        hudPanel.SetActive(false);
        gameOverTitle.text = message.Contains("Victory") || message.Contains("Wins") ? "🎉 VICTORY!" : "💀 DEFEAT";
        gameOverMessage.text = message;
    }

    public void OnReturnToMenu()
    {
        ShowMenu();
    }

    void ShowMenu()
    {
        menuPanel.SetActive(true);
        hudPanel.SetActive(false);
        gameOverPanel.SetActive(false);
        GameManager.Instance.selectedPokemon = null;
        GameManager.Instance.selectedPokemonP2 = null;
        selectedLabel.text = "Choose your fighter!";
        foreach (var kvp in pokemonButtons)
            SetButtonSelected(kvp.Value, false);
        startButton.interactable = false;
    }

    // ============================================================
    // UI HELPERS
    // ============================================================

    GameObject CreatePanel(string name, Color bgColor)
    {
        var go = new GameObject(name);
        go.transform.SetParent(mainCanvas.transform, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
        var img = go.AddComponent<Image>();
        img.color = bgColor;
        img.raycastTarget = bgColor.a > 0;
        return go;
    }

    Text CreateText(Transform parent, string content, int fontSize, Vector2 pos, Color color)
    {
        var go = new GameObject("Text");
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(1000, 60);
        var text = go.AddComponent<Text>();
        text.text = content;
        text.fontSize = fontSize;
        text.color = color;
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.alignment = TextAnchor.MiddleCenter;
        return text;
    }

    Button CreateButton(Transform parent, string label, Vector2 pos, float w, float h, Color? color = null)
    {
        var go = new GameObject("Btn_" + label);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(w, h);
        var img = go.AddComponent<Image>();
        img.color = color ?? new Color(0.2f, 0.2f, 0.3f);

        var btn = go.AddComponent<Button>();
        var colors = btn.colors;
        colors.highlightedColor = new Color(1, 1, 1, 0.3f);
        colors.pressedColor = new Color(1, 1, 1, 0.5f);
        btn.colors = colors;

        var textGO = new GameObject("Label");
        textGO.transform.SetParent(go.transform, false);
        var textRT = textGO.AddComponent<RectTransform>();
        textRT.anchorMin = Vector2.zero;
        textRT.anchorMax = Vector2.one;
        textRT.offsetMin = Vector2.zero;
        textRT.offsetMax = Vector2.zero;
        var text = textGO.AddComponent<Text>();
        text.text = label;
        text.fontSize = 16;
        text.color = Color.white;
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.alignment = TextAnchor.MiddleCenter;

        return btn;
    }

    Slider CreateHpBar(Transform parent, Vector2 pos, float width, string label)
    {
        var go = new GameObject("HpBar_" + label);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(width, 20);

        // Background
        var bgGO = new GameObject("Bg");
        bgGO.transform.SetParent(go.transform, false);
        var bgRT = bgGO.AddComponent<RectTransform>();
        bgRT.anchorMin = Vector2.zero;
        bgRT.anchorMax = Vector2.one;
        bgRT.offsetMin = Vector2.zero;
        bgRT.offsetMax = Vector2.zero;
        bgGO.AddComponent<Image>().color = new Color(0.2f, 0.2f, 0.2f);

        // Fill
        var fillGO = new GameObject("Fill");
        fillGO.transform.SetParent(go.transform, false);
        var fillRT = fillGO.AddComponent<RectTransform>();
        fillRT.anchorMin = Vector2.zero;
        fillRT.anchorMax = Vector2.one;
        fillRT.offsetMin = Vector2.zero;
        fillRT.offsetMax = Vector2.zero;
        fillGO.AddComponent<Image>().color = new Color(0.18f, 0.8f, 0.44f);

        var slider = go.AddComponent<Slider>();
        slider.fillRect = fillRT;
        slider.interactable = false;
        slider.maxValue = 1;
        slider.value = 1;

        // Label
        CreateText(go.transform, label, 14, new Vector2(0, -20), Color.white);

        return slider;
    }

    void SetButtonSelected(Button btn, bool selected)
    {
        var img = btn.GetComponent<Image>();
        if (selected)
        {
            var c = img.color;
            c.a = 1f;
            img.color = c;
        }
        else
        {
            var c = img.color;
            c.a = 0.4f;
            img.color = c;
        }
    }
}
